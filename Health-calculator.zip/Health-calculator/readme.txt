HEALTH CALCULATOR. 

== Description ==
This is a basic Health Calculator that generates a short feedback when used.This Health calculator is for adults only.This will generate a health score by using inputs by user .There are 3 inputs required,first is height in feet,second is inches and third one is weight in killograms.
This calculator used the body mass index to generate a health score and give right feedback to the users.
It can be placed on sidebar as widget or incorporated into post or page using shortcode. 

== Installation ==

1. Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Appearance -> Widgets and add the widget to your website sidebar

